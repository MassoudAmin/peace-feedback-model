# Peace as a Coupled Feedback System — replication package

Companion to: Amin SM. Peace as a coupled feedback system: loops, thresholds, and an out-of-sample test on armed-conflict onsets, 1991–2025. Manuscript, September 2026.

## Contents
- code/  — Python scripts. Each runs from the public data files named in the paper (Section 4) and writes the tables in Section 6.
  - fit1.py  onset and escalation models, FAO and SIPRI (Sections 6.1, 6.4, 6.5)
  - fit2.py  monthly revenge loop and escalation ladder (Table 1)
  - fit3.py  V-Dem institutions and 1946 history (Table 2, Section 6.2, 6.8)
  - food.py, food2.py, food3.py  WFP and World Bank food-price tests (Section 6.5)
  - res.py   reserves and the buffer interaction (Table 3)
  - tone.py, tone2.py  ICEWS press-hostility tests (Section 6.7)
  - predict.py  test-war ranks and the 2026 ranking (Figure 3, Appendix B)
  - fig4.py, loops4.py, fig2.py, peace_eq2.py  figures and the equation sheet
- panels/ — the country-year and country-month panels the scripts build, so every table can be checked without re-downloading 1 GB of source data.
- figures/ — the figures as vector PDF.

## Data
All sources are public: UCDP 26.1, UCDP/PRIO ACD 26.1, V-Dem v16, SIPRI Military Expenditure Database, FAO Food Price Index, World Bank Global Database of Inflation and FI.RES.TOTL.MO, WFP Global Food Prices, ICEWS. File names expected by the scripts are given at the top of each script.

## Requirements
Python 3.10+, pandas, numpy, scikit-learn, matplotlib, pycountry. Every script runs in under one minute on a laptop.

## Forecast on record
panels/rank2026.csv is the model's ranking for 2026, made from 2025 data on 24 September 2026, before any 2026 figures were available. Score it against UCDP's 2026 release.
